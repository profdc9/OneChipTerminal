/* Font definitions */

#ifndef _TNTSCCHARFONT_H
#define _TNTSCCHARFONT_H

extern const unsigned char raster88_font[][8];

#endif  /* _TNTSCCHARFONT_H */

